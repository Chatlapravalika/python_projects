
Contact Management System - Python Project

Features:
- Add contacts
- View contacts
- Delete contacts
- Simple menu-driven program

How to Run:
1. Install Python
2. Open terminal
3. Run: python contact_manager.py

Suitable for:
- Beginners
- College mini project
- GitHub upload
