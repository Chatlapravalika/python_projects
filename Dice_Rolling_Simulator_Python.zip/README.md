
# Dice Rolling Simulator 🎲

A simple Python project that simulates rolling a dice.

## Features
- Generates random dice numbers (1–6)
- User-friendly console interface
- Beginner-friendly project

## How to Run
1. Install Python
2. Run:
   python main.py

## Concepts Used
- random module
- loops
- functions
