
import random

def roll_dice():
    return random.randint(1, 6)

def main():
    print("🎲 Dice Rolling Simulator 🎲")

    while True:
        choice = input("Roll the dice? (y/n): ").lower()
        if choice == 'y':
            number = roll_dice()
            print(f"You rolled: {number}")
        elif choice == 'n':
            print("Thank you for playing!")
            break
        else:
            print("Invalid choice! Please enter y or n.")

if __name__ == "__main__":
    main()
