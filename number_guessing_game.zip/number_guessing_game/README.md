# Number Guessing Game
A beginner Python game where the player guesses a random number within limited attempts. Great for practicing loops, conditionals, and the random module.
