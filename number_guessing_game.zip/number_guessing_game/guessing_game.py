# Number Guessing Game
import random

def game():
    number = random.randint(1, 100)
    attempts = 5
    print("Guess the number between 1 and 100. You have 5 attempts!")
    while attempts > 0:
        try:
            guess = int(input("Enter your guess: "))
        except ValueError:
            print("Enter a valid number.")
            continue
        if guess == number:
            print("Correct! You win!")
            return
        elif guess < number:
            print("Too low!")
        else:
            print("Too high!")
        attempts -= 1
    print(f"Out of attempts! The number was {number}.")

if __name__ == "__main__":
    game()
