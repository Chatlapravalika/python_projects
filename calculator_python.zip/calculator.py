#!/usr/bin/env python3
"""Simple and safe Python Calculator (CLI)

Supports: +, -, *, /, %, **, parentheses, unary +/-, and floats/ints.
Usage: run `python3 calculator.py` and enter expressions or 'quit' to exit.
"""
import ast
import operator as op

# supported operators
operators = {
    ast.Add: op.add,
    ast.Sub: op.sub,
    ast.Mult: op.mul,
    ast.Div: op.truediv,
    ast.Pow: op.pow,
    ast.Mod: op.mod,
    ast.USub: op.neg,
    ast.UAdd: op.pos,
    ast.FloorDiv: op.floordiv,
}

def safe_eval(expr):
    """Evaluate an arithmetic expression safely using ast."""
    try:
        node = ast.parse(expr, mode='eval').body
        return _eval_node(node)
    except Exception as e:
        raise ValueError(f"Invalid expression: {e}") from e

def _eval_node(node):
    if isinstance(node, ast.BinOp):
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        op_type = type(node.op)
        if op_type in operators:
            return operators[op_type](left, right)
        raise ValueError(f"Unsupported operator: {op_type.__name__}")
    elif isinstance(node, ast.UnaryOp):
        operand = _eval_node(node.operand)
        op_type = type(node.op)
        if op_type in operators:
            return operators[op_type](operand)
        raise ValueError(f"Unsupported unary operator: {op_type.__name__}")
    elif isinstance(node, ast.Num):  # Python <3.8
        return node.n
    elif isinstance(node, ast.Constant):  # Python 3.8+
        if isinstance(node.value, (int, float)):
            return node.value
        raise ValueError("Only numeric constants are allowed")
    elif isinstance(node, ast.Expr):
        return _eval_node(node.value)
    else:
        raise ValueError(f"Unsupported expression: {type(node).__name__}")

def repl():
    print("Simple Python Calculator — enter arithmetic expressions or 'quit' to exit.")
    print("Supported: + - * / % ** parentheses. Examples: 2+2, (3+4)*5, -2**3")
    while True:
        try:
            expr = input('> ').strip()
            if expr.lower() in {'quit','exit'}:
                print('Goodbye!')
                break
            if not expr:
                continue
            result = safe_eval(expr)
            print(result)
        except Exception as e:
            print('Error:', e)

if __name__ == '__main__':
    repl()
