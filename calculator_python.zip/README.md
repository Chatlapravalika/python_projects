# Simple Python Calculator

A small, safe command-line calculator in Python that evaluates arithmetic expressions using Python's AST module.
Supports: +, -, *, /, %, ** (power), unary +/-, parentheses, integers and floats.

## Usage
```bash
python3 calculator.py
```
Type expressions like `2+2`, `(3+4)*5`, `10/3`, or `2**8`. Type `quit` or `exit` to leave.

## Files
- `calculator.py` — main calculator script (safe evaluator).
- `README.md` — this file.
- `LICENSE` — MIT license.
